import React from "react";

export default function Home() {
  const products = [
    {
      id: 1,
      name: "Cracked Tool",
      description: "Powerful tool for automated tasks.",
      price: "$25",
      link: "https://instagram.com/nmdh"
    },
    {
      id: 2,
      name: "Spoofing App",
      description: "Bypass detections and change device IDs.",
      price: "$40",
      link: "https://instagram.com/nmdh"
    },
    {
      id: 3,
      name: "Private Checker",
      description: "Scan accounts with custom rules.",
      price: "$30",
      link: "https://instagram.com/nmdh"
    }
  ];

  return (
    <div className="min-h-screen bg-black text-white px-6 py-12">
      <header className="mb-12 text-center">
        <h1 className="text-4xl font-bold">booka.cc</h1>
        <p className="text-gray-400 mt-2">Tools. Services. No fluff.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {products.map(product => (
          <div key={product.id} className="bg-zinc-900 p-6 rounded-2xl shadow-md">
            <h2 className="text-xl font-semibold mb-2">{product.name}</h2>
            <p className="text-gray-400 mb-4">{product.description}</p>
            <p className="text-lg mb-4">{product.price}</p>
            <a
              href={product.link}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-black font-medium px-4 py-2 rounded-xl"
            >
              Buy Now
            </a>
          </div>
        ))}
      </div>

      <footer className="mt-20 text-center text-gray-600 text-sm">
        &copy; {new Date().getFullYear()} booka.cc. All rights reserved.
      </footer>
    </div>
  );
}